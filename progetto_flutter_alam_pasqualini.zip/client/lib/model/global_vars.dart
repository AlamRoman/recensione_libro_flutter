
String globalContentType = "application/xml";
var userToken = "";