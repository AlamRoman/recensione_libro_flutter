package com.example.gestione_recensioni

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
